/*
 * Filename   main.cc
 * Date       2/13/2021
 * Author     Evan Roman
 * Email      emr180004@utdallas.edu
 * Course     CS 3377.0W6 Spring 2021
 * Version    1.1
 * Copyright  2021, All Rights Reserved
 * 
 * Description
 * A main C++ file that creates the different types of objects for TCLAP to
 * parse the cmd line. These objects will be registered to the CmdLine object,
 * put into a map, and then a file will be read using the results of TCLAP to
 * manipulate the data according to what the user put.
 */

#include "optionMap.h"
#include "readFile.h"
#include "indexList.h"

int main(int argc, char* argv[]) {
  // Create cmd object, which will parse the argv arr based on the Arg objects it contains
  CmdLine cmd("CS 3377.0W6 Program 3", ' ', "1.0");
  // Create ValueArg object for output file
  ValueArg<string> outfileArg("o", "outfile", "The name of the output file", false,
			      "output.txt", "output filename");
  // Register outfileArg
  cmd.add(outfileArg);
  // Create SwitchArg object for uppercase
  SwitchArg upperSwitch("u", "upper", "Convert all text to uppercase", cmd, false);
  // Create SwitchArg object for lowercase
  SwitchArg lowerSwitch("l", "lower", "Convert all text to lowercase", cmd, false);
  // Create UnlabeledValueArg object for input file
  UnlabeledValueArg<string> infileArg("infile", "Input file", true, "infile.txt",
				      "input filename", false);
  // Register infileArg
  cmd.add(infileArg);
  // Parse cmd line
  cmd.parse(argc, argv);
  // Put results from TCLAP into map
  map<int, string> optionMap = storeResults(upperSwitch, lowerSwitch, outfileArg, infileArg);
  // Check if -u and -l are both on cmd line
  if (optionMap[UPPER] == "true" && optionMap[LOWER] == "true") {
    cmd.getOutput()->usage(cmd);  // Print usage
    exit(EXIT_FAILURE);  // Exit program
  }
  // Perform file I/O
  readFile(optionMap);
}
