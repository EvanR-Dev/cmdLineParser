/*
 * Filename   indexList.h
 * Date       2/13/2021
 * Author     Evan Roman
 * Email      emr180004@utdallas.edu
 * Course     CS 3377.0W6 Spring 2021
 * Version    1.0
 * Copyright  2021, All Rights Reserved
 *
 * Description
 * A header file that contains an enum for indexing
 * the optionMap, which holds the result of TCLAP.
 */

#ifndef INDEXLIST_H
#define INDEXLIST_H

enum cmdArg {UPPER, LOWER, OUTFILE, INFILE};

#endif
