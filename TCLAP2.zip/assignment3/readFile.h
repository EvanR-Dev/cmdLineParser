/*
 * Filename   readFile.h
 * Date       2/13/2021
 * Author     Evan Roman
 * Email      emr180004@utdallas.edu
 * Course     CS 3377.0W6 Spring 2021
 * Version    1.0
 * Copyright  2021, All Rights Reserved
 *
 * Description
 * A header file that contains the function
 * prototype for the readFile routine.
 */

#ifndef READFILE_H
#define READFILE_H

#include <map>
#include <string>

using namespace std;

void readFile(map<int, string>&);

#endif
