/*
 * Filename   optionMap.cc
 * Date       2/13/2021
 * Author     Evan Roman
 * Email      emr180004utdallas.edu
 * Course     CS 3377.0W6 Spring 2021
 * Version    1.2
 * Copyright  2021, All Rights Reserved
 *
 * Description
 * A cc file that will store the results of TCLAP into
 * a map with ints as keys and strings as values. Has
 * indexList.h to use the enum for indexing and optionMap.h
 * for the prototype.
 */

#include "optionMap.h"
#include "indexList.h"
#include <tclap/CmdLine.h>

map<int, string> storeResults(SwitchArg& u, SwitchArg& l, ValueArg<string>& out, UnlabeledValueArg<string>& in) {
  map<int, string> opMap;  // Create local map to be returned
  opMap[UPPER] = opMap[LOWER] = "false"; // Assume both are false (not on cmd line)

  if (u.getValue())  // -u was an arg
    opMap[UPPER] = "true";  // Indicate true
  if (l.getValue())  // -l was an arg
    opMap[LOWER] = "true";  // Indicate true
  opMap[OUTFILE] = out.getValue();  // Get str value for output file
  opMap[INFILE] = in.getValue();  // Get str value for input file

  return opMap;
}
