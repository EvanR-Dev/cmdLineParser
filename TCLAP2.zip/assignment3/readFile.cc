/*
 * Filename   readFile.cc
 * Date       2/13/2021
 * Author     Evan Roman
 * Email      emr180004@utdallas.edu
 * Course     CS 3377.0W6 Spring 2021
 * Version    1.2
 * Copyright  2021, All Rights Reserved
 *
 * Description
 * A cc file that contains a routine to open a given file, read it,
 * and then write to an output file, changing the case of words depending
 * on what was given on the cmd line. This info is already stored in
 * the map from main.
 */

#include "indexList.h"
#include "readFile.h"
#include <iostream>
#include <fstream>
#include <locale>
#include <stdlib.h>

using namespace std;

void readFile(map<int, string>& opMap) {
  ifstream inFile;  // Input file object
  inFile.open(opMap[INFILE].c_str(), ios::in); // Open input file for reading
  if (!inFile.is_open()) {  // Check if input file opened
    cout << "Input file did NOT open. Check if file exists or the directory.\n";
    exit(EXIT_FAILURE);
  }

  ofstream outFile;  // Output file object
  outFile.open(opMap[OUTFILE].c_str(), ios::out);  // Open output file to write to
  if (!outFile.is_open()) {  // Check is output file opened
    cout << "Output file did NOT open. Check if file exists or the directory.\n";
    exit(EXIT_FAILURE);
  }
  // Read input file and write to output file
  string line; locale loc;
  while (getline(inFile, line)) {
    if (opMap[UPPER] == "true")  // Change all to upper
      for (int i = 0; i < line.length(); i++)
	outFile << toupper(line[i], loc);
    else if (opMap[LOWER] == "true")  // Change all to lower
      for (int i = 0; i < line.length(); i++)
	outFile << tolower(line[i], loc);
    else  // Do not change output
      outFile << line;
    outFile << '\n';
  }
  inFile.close();  // Close input file
  outFile.close();  // Close output file
}
