/*
 * Filename   optionMap.h
 * Date       2/13/2021
 * Author     Evan Roman
 * Email      emr180004@utdallas.edu
 * Course     CS 3377.0W6 Spring 2021
 * Version    1.2
 * Copyright  2021, All Rights Reserved
 *
 * Description
 * A header file the contains the prototype for the storeResults routine
 * to store the results of TCLAP in a map.
 */

#ifndef OPTIONMAP_H
#define OPTIONMAP_H

#include <map>
#include <tclap/CmdLine.h>

using namespace std;
using namespace TCLAP;

map<int, string> storeResults(SwitchArg&, SwitchArg&, ValueArg<string>&, UnlabeledValueArg<string>&);

#endif
